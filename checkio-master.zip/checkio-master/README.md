checkio
=======

solutions of checkio

You are welcome to follow my
Checkio ID: hujingyuan


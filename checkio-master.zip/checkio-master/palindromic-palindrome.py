__author__ = 'jingyuan'

"a\";]1-::[x==x:x adbmal=oikcehc;";checkio=lambda x:x==x[::-1];"\a"
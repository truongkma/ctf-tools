import challenge31_server

if __name__ == '__main__':
    challenge31_server.serve_forever(0.005)

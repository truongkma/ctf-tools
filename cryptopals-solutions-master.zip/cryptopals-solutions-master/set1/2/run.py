#! /usr/bin/env python

print "Input string 1: "
a = int(raw_input(),16)
print "Input string 2: "
b = int(raw_input(),16)
print "XORed result: %X" % (a^b)

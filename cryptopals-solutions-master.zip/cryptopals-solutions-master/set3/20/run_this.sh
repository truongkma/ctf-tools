#! /bin/sh

### The crazy looking ^ signs below cause an adjustment to the statistically found keys by moving through
### other possible keys. The number of times that ^ has been put and the positioning for each has been
### found through manually running the python script and inputting things. Note: The last part of 2 of
### the longest messages was too much work, so I didn't bother doing it.

python run.py <<EOF
^
                                                                                                     ^
                                                                                                     ^
                                                                                                     ^
                                                                                                     ^
                                                                                                       ^
                                                                                                         ^
                                                                                                         ^
                                                                                                         ^
                                                                                                         ^
                                                                                                           ^
                                                                                                           ^
                                                                                                           ^
                                                                                                           ^

EOF

from __future__ import absolute_import

import sys as a
from .. import sys as b

def foo(): pass

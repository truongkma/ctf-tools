import relative_import.x
import relative_import.x.module

if __name__ == "__main__":
    print relative_import.x.a.maxint
    print relative_import.x.b.maxint

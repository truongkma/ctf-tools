# This tests http://sourceforge.net/project/showfiles.php?group_id=6473

import xml.xpath

if __name__ == "__main__":
    print xml.xpath.Init()

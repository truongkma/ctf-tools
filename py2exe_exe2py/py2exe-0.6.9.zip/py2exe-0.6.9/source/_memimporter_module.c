#define STANDALONE
#include "_memimporter.c"

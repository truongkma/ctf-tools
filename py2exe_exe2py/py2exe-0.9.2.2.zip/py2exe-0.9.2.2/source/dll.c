/*
  Will be compiled to a resource-only dll.
  No code here.
*/

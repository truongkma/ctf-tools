Most search algorithms are from [Fahiem Bacchus](http://www.cs.toronto.edu/~fbacchus/), [University of Toronto](http://utoronto.ca).

I contributed [IDA* search](http://en.wikipedia.org/wiki/IDA*) and path checking, as well as some sample code for solving the [8 puzzle](http://en.wikipedia.org/wiki/Fifteen_puzzle) and the [Missionaries and Cannibals](http://en.wikipedia.org/wiki/Missionaries_and_cannibals_problem) problem.


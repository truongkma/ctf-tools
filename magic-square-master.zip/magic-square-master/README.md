magic-cube
==========

a simple magic cube excersize in python

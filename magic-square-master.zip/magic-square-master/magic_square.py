#!/usr/bin/env python
"""This program solves Magic Cubes."""

class MagicSquare(object):
    """This is the Magic Square class. It contains the logic common to all
    Magic Squares."""

    def __new__(cls, size):

        if cls is MagicSquare:

            if size % 2 != 0:

                subclass_to_create = OddSizedMagicSquare

            else:
                subclass_to_create = EvenSizedMagicSquare

            return object.__new__(subclass_to_create, size)

        else:

            return object.__new__(cls, size)


    def __init__(self, size):

        self.size = size

        self.matrix = None


    def __str__(self):

        if self.matrix:

            string_representation_of_square = ''

            longest_cell_value_string = len(str(self.size))

            for row in self.matrix:

                for cell in row:

                    string_representation_of_square += \
                    (' ' * (longest_cell_value_string \
                    - len(str(cell)) + 1)) + ' ' + str(cell)


                string_representation_of_square += '\n'


            return string_representation_of_square

        else:
            return 'An empty %s sized square.' % self.size

    def get_magic_sum(self):
        """Returns the Magic Sum of a Magic Square."""

        return (self.size * (self.size**2 + 1)) / 2


    def get_solved_square(self):
        """Returns a solved square"""

        matrix = []

        for row in range(self.size):

            matrix.append([])
            for cell in range(self.size):

                matrix[row].append(self.get_solved_cell(row, cell))


        return matrix


    def solve_square(self):
        """Stores a solved square in `self.matrix`."""

        self.matrix = self.get_solved_square()


    def get_solved_cell(self, row, cell):
        """A dummy method for pylint to not complain about call to this
        function in `self.get_solved_square`"""

        pass


class OddSizedMagicSquare(MagicSquare):
    """This is the class for the odd-sized Magic Squares."""

    def get_solved_cell(self, row, cell):
        """Returns the solved number for a given cell in the Odd Magic
        Square."""

        return self.size * ((row + cell - 1 + (self.size / 2)) \
        % self.size ) + ((row + (2 * cell) - 2) % self.size) + 1

class EvenSizedMagicSquare(MagicSquare):
    """ This is the class for the even-sized Magic Squares."""

    pass

if __name__ == '__main__':

    SQUARE = MagicSquare(int(raw_input('Please enter square size:\n')))
    print('Magic sum: ' + str(SQUARE.get_magic_sum()))

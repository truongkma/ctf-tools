import urllib,cStringIO
from StringIO import StringIO
from PIL import Image
import gmpy, requests
from pytesser import *
import re
url = 'http://ctf.framgia.vn:1990/index'
session = requests.Session()
response = session.get(url)
print session.cookies.get_dict()
#url = 'http://ctf.framgia.vn:1990/index'
#r = requests.get(url)
#ck = {'PHPSESSID':r.cookies['PHPSESSID']}
r = requests.get(url, cookies=session.cookies.get_dict())
while True:
	code = r.text.split('src="')[3].split('"')[0]
	code = "http://ctf.framgia.vn:1990"+ code
	urllib.urlretrieve(code,'1.png')
	im = Image.open('1.png')
	im.save('11.tif')
	im = Image.open('11.tif')
	p = image_to_string(im)
	ss = """and &,or |,A (^),% mod,  , xor A , plus +, minus -,mul *  """
	number = re.findall('\d+',p)
	ks = re.findall('\D+',p)
	#kq = 0
	for i in range(2):
		pt = ks[i]
		if '*' in pt:
			kq = int(number[0])*int(number[1])
		if 'mul' in pt:
			kq = int(number[0])*int(number[1])
		if 'mu|' in pt:
			kq = int(number[0])*int(number[1])
		if 'A' in pt:
			kq = int(number[0])^int(number[1])
		if 'xor' in pt:
			kq = int(number[0])^int(number[1])
		if 'and' in pt:
			kq = int(number[0])&int(number[1])
		if '&' in pt:
			kq = int(number[0])&int(number[1])
		if 'or' in pt:
			kq = int(number[0])|int(number[1])
		if '|' in pt:
			kq = int(number[0])|int(number[1])
		if '+' in pt:
			kq = int(number[0])+int(number[1])
		if 'plus' in pt:
			kq = int(number[0])+int(number[1])
		if 'mod' in pt:
			kq = int(number[0])%int(number[1])
		if '%' in pt:
			kq = int(number[0])%int(number[1])
		if '-' in pt:
			kq = int(number[0])-int(number[1])
		if 'minus' in pt:
			kq = int(number[0])-int(number[1])
	print kq
	payload = {'data':kq}
	r = requests.post(url, cookies=session.cookies.get_dict(), data=payload)
	if 'flag{' in r.text:
		print r.text

#undef andn
#define andn 0
#include "opencl_nonstd.h"
